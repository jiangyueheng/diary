package com.example.superdailytest;

public class usesp {

}
