package com.example.superdailytest;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.Nullable;

public class ShowAuthor extends Activity {

    private String data[] = {"作者信息"," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "
            ," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "
            ," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "
            ," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "," "};//空数据
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.showauthor);
        SharedPreferences editor = getSharedPreferences("authordata", Context.MODE_PRIVATE);
        int numbb=editor.getInt("num",0);//num为作者的数量
        int j;
        int blank=0;
        for(int i=1;i<=numbb;i++){
            for(j=i-1;j>=1;j--){
               // System.out.println("aaa"+editor.getString(""+j,"data[i]")+" ss "+editor.getString(""+i,"data[i]"));
                if(editor.getString(""+i,"data[i]").equals(editor.getString(""+j,"data[i]"))){//判断是否有重复作者
                    System.out.println("aaa"+editor.getString(""+j,"data[i]")+" ss "+editor.getString(""+i,"data[i]"));
                    break;
                }

            }
            System.out.println("j="+j);
            if(j>=1){
                blank++;
                continue;
            }

            System.out.println(editor.getString("8","data[i]"));
            data[i-blank]=editor.getString(""+i,"data[i]");
            if(editor.getString(String.valueOf(i),"data[i]")=="data[i]"){
                break;
            }
        }
        ListView listView = (ListView) findViewById(R.id.aalist);//在视图中找到ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,data);//新建并配置ArrayAapeter
        listView.setAdapter(adapter);
    }
}
