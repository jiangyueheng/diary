package com.example.superdailytest;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddContent extends Activity implements View.OnClickListener {
    private String val;
    private Button savebtn,deletebtn;
    private EditText ettext,titletext,authortext;
    private ImageView c_img;
    private VideoView v_video;
    private NotesDB notesDB;
    private SQLiteDatabase dbWriter;
    private File phoneFile,videoFile;
    private Uri imageUri;
    public static final int TAKE_PHOTO = 1;
    public int a1=0;
    @Override

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addcontent);
        val=getIntent().getStringExtra("flag");
        savebtn = (Button)findViewById(R.id.save);
        deletebtn = (Button)findViewById(R.id.delete);
        ettext = (EditText)findViewById(R.id.ettext);
        titletext=(EditText)findViewById(R.id.titletext);
        authortext = (EditText)findViewById(R.id.authortext);
        c_img = (ImageView)findViewById(R.id.c_img);
        v_video = (VideoView) findViewById(R.id.c_video);
        savebtn.setOnClickListener(this::onClick);
        deletebtn.setOnClickListener(this::onClick);
        notesDB = new NotesDB(this);
        dbWriter = notesDB.getWritableDatabase();


        try {
            initView();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void initView() throws IOException {
        System.out.println("caiadjaidojad"+val);
        if(val.equals("1")){//是1就是纯文字
            c_img.setVisibility(View.GONE);
            v_video.setVisibility(View.GONE);
        }
        else if(val.equals("2")){
            c_img.setVisibility(View.VISIBLE);
            v_video.setVisibility(View.GONE);


            phoneFile = new File(getExternalCacheDir(), getTime()+"output_image.jpg");
            if(phoneFile.exists()){
                phoneFile.delete();
            }
            phoneFile.createNewFile();
             if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.N){
                imageUri = FileProvider.getUriForFile(this,"com.example.SuperDailyTest.fileprovider",phoneFile);
            }else {
                 imageUri=Uri.fromFile(phoneFile);
             }
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            a1=1;
            startActivityForResult(intent, TAKE_PHOTO);





        }
        else if(val.equals("3")){
            c_img.setVisibility(View.GONE);
            v_video.setVisibility(View.VISIBLE);
            Intent video = new Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA);
            videoFile = new File(Environment.getExternalStorageDirectory().getAbsoluteFile()+"/"+getTime()+".mp4");
            video.putExtra(MediaStore.EXTRA_OUTPUT,Uri.fromFile(phoneFile));
            startActivityForResult(video,2);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println("aaa显示土图片"+requestCode+(resultCode == TAKE_PHOTO));
        if(a1==1){
            a1=0;
            System.out.println("显示土图片");
            Bitmap bitmap = null;
            try {
                bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(imageUri));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            c_img.setImageBitmap(bitmap);
        }
        if(requestCode ==2){
            v_video.setVideoURI(Uri.fromFile(videoFile));
            v_video.start();
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.save:
                addDB();
                finish();
                break;
            case R.id.delete:
                finish();
                break;
        }
    }

    public  void addDB(){
        ContentValues cv = new ContentValues();
        cv.put(NotesDB.CONTENT,ettext.getText().toString());
        if(titletext.getText().toString().equals("")){
            Toast.makeText(getApplicationContext(), "标题不能为空", Toast.LENGTH_SHORT).show();
            System.out.println("biaotikong");

        }else {
            cv.put(NotesDB.TITLE,titletext.getText().toString());
            if(authortext.getText().toString().equals("")){
                authortext.setText("小猪");
            }
            cv.put(NotesDB.AUTHOR,authortext.getText().toString());
            cv.put(NotesDB.TIME,getTime());
            cv.put(NotesDB.PATH,phoneFile+"");
            cv.put(NotesDB.VIDEO,videoFile+"");
            dbWriter.insert(NotesDB.TABLE_NAME,null,cv);
            SharedPreferences sp = getSharedPreferences("authordata", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            int numbbb=sp.getInt("num",0)+1;
            editor.putInt("num",numbbb);
            editor.putString(""+numbbb,""+authortext.getText().toString());
            editor.apply();
        }


    }
    private  String getTime(){
        SimpleDateFormat format = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
        Date date = new Date();
        String str = format.format(date);
        return str;
    }
}
